package diaballik.model;

public interface BoardBuilder {

	public abstract Board buildBoard();

}
