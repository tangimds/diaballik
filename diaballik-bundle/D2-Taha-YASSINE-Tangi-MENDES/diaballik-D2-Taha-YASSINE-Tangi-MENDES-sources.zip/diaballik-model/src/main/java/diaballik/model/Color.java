package diaballik.model;

public enum Color { WHITE, BLACK};
