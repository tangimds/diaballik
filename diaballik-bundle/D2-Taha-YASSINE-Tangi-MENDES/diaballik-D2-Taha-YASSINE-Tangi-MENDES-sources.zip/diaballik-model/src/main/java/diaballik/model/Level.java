package diaballik.model;

public interface Level {

	public abstract Action chooseAction(Board board);

}
